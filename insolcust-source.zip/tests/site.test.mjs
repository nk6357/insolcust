import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("build contains the customer landing and real contact form", async () => {
  const [html, page, handler] = await Promise.all([
    readFile(new URL("../dist/client/index.html", import.meta.url), "utf8"),
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../beget/send.php", import.meta.url), "utf8"),
  ]);

  assert.match(html, /INSOL — подбор AI‑разработчиков для бизнеса/);
  assert.match(page, /Опишите AI‑проект/);
  assert.match(page, /name="task" required/);
  assert.match(page, /fetch\("\/send\.php"/);
  assert.match(handler, /mail\(\$to/);
  assert.match(handler, /csrf_token/);
  assert.match(handler, /insol-customer-form-rate/);
});
